# ReaDirect Adaptive Fluency CSV Update v2

## Purpose

This update fixes the previous active-only cleanup by respecting the ASR-hard inactive policy and adding sentence-level pacing targets for Module 3.

## Core Scoring Rule

For full sentence and paragraph reading, the fluency metric should be pure WCPM:

```text
correct_words = max(total_words_read - errors, 0)
wcpm = correct_words / (duration_seconds / 60)
```

Do not combine pacing penalties into the numeric fluency value. Pacing should be stored as a separate feedback and mastery signal so Ciel can say whether the learner read too fast, fluent, or too slow.

## Pacing Rule for Module 3

Each Module 3 row now has:

- `target_read_time_seconds`
- `min_fluent_time_seconds`
- `max_fluent_time_seconds`
- `target_wcpm`
- `min_expected_wcpm`
- `max_expected_wcpm`
- `pace_feedback_rule`
- `pace_mastery_required`

The target is based on the rule implied by the example:

```text
6 words / 3 seconds = 120 WPM target pace
```

So the generated target is roughly 2 words per second, with a one-second tolerance window. Example:

```text
"Mordred is the son of Arthur" = 6 words
Target = 3.0 seconds
Too fast = below 2.0 seconds
Fluent = 2.0 to 4.0 seconds
Too slow = above 4.0 seconds
```

## ASR-Hard Inactive Policy

Inactive rows should not be treated as filler. They are inactive because the ASR had difficulty identifying or distinguishing them.

For Module 1 letters, the ASR-hard isolated letters are:

```text
P, D, B, Z
```

These rows are retained in the CSV but marked inactive with metadata explaining that they should not be used for live scoring until ASR improves or a special fallback scorer is implemented.

## Output Row Counts

| File | Rows | Active | Inactive |
|---|---:|---:|---:|
| Module 1 | 130 | 110 | 20 |
| Module 2 | 164 | 164 | 0 |
| Module 3 | 241 | 241 | 0 |

## Implementation Notes

1. Laravel/content-bank import should allow the new Module 3 columns.
2. ASR response should return `duration_seconds`, `word_errors`, `total_words_read`, and `wcpm`.
3. Module 3 frontend should display WCPM as the fluency metric.
4. Ciel should use the time window to give pace feedback:
   - below `min_fluent_time_seconds` = too fast
   - within range = fluent/perfect pace
   - above `max_fluent_time_seconds` = too slow
5. Adaptive routing should use both accuracy and pacing:
   - correct + fluent pace = mastery progress
   - correct + too fast = repeat with “slow down” coaching
   - correct + too slow = repeat with “smooth reading” coaching
   - errors = normal ASR word-error remediation
