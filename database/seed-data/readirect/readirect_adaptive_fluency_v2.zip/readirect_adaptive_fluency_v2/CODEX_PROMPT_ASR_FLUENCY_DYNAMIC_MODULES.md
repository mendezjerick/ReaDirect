# Codex Prompt: ReaDirect ASR Fluency + Dynamic Module 3 Timing

Update ReaDirect's sentence and paragraph reading scoring so fluency is scored as pure WCPM and pacing is handled as a separate feedback/mastery signal.

## Required Behavior

1. Full sentence and paragraph reading must calculate:

```text
correct_words = max(total_words_read - errors, 0)
wcpm = correct_words / (duration_seconds / 60)
```

2. Do not use a vague fluency score. The displayed fluency metric after reading should be WCPM.

3. Module 3 content-bank rows now include:

```text
target_read_time_seconds
min_fluent_time_seconds
max_fluent_time_seconds
target_wcpm
min_expected_wcpm
max_expected_wcpm
pace_feedback_rule
pace_mastery_required
```

4. Use the recorded speech duration to classify pace:

```text
if duration_seconds < min_fluent_time_seconds:
    pace_label = "too_fast"
elif duration_seconds > max_fluent_time_seconds:
    pace_label = "too_slow"
else:
    pace_label = "fluent"
```

5. The numeric fluency value remains WCPM. Pacing affects feedback and mastery routing, not the WCPM formula itself.

## ASR Response Contract

For sentence/paragraph items, return at least:

```json
{
  "total_words_read": 6,
  "errors": 0,
  "correct_words": 6,
  "duration_seconds": 3.0,
  "wcpm": 120.0,
  "pace_label": "fluent",
  "target_read_time_seconds": 3.0,
  "min_fluent_time_seconds": 2.0,
  "max_fluent_time_seconds": 4.0
}
```

## Ciel IA Feedback

Ciel should interpret `pace_label` like this:

- `too_fast`: learner may be rushing; say: “Slow down a little so each word is clear.”
- `fluent`: learner has good pace; say: “Great pace. You read it clearly and smoothly.”
- `too_slow`: learner may be pausing too much; say: “Try reading it a little smoother without long pauses.”

## Mastery Routing

For Module 3:

- correct words + fluent pace = count toward mastery
- correct words + too fast = repeat a similar sentence with pacing coaching
- correct words + too slow = repeat a similar sentence with smooth-reading coaching
- word errors = remediation using missed/skipped/substituted word categories

## Inactive Row Rule

Do not reactivate rows that were intentionally inactive due to ASR identification problems.

For Module 1, keep isolated letters P, D, B, and Z inactive because they are ASR-hard. These rows may remain in the content bank as inactive references, but they must not appear in live learner scoring until the ASR model or fallback scorer is improved.
