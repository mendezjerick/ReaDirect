Run: `uvicorn api.main:app --host 127.0.0.1 --port 8001`
